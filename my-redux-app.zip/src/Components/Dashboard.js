import React from "react";

export default function Dashboard() {
  return (
    <div className="dashboard">
      <h1>Dashboard Component</h1>
    </div>
  );
}