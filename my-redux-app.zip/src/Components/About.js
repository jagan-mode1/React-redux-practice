import React from "react";

export default function About() {
  return (
    <div className="about">
      <h1>About Component</h1>
    </div>
  );
}