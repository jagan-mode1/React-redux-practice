import {BUY_LAPTOP} from "./actionTypes";
import {BUY_MOBILE} from "./actionTypes";
export const buyLaptop=()=>{
    return {
        type:BUY_LAPTOP
    }
}
export const buyMobile=()=>{
    return {
        type:BUY_MOBILE
    }
}