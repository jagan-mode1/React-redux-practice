export const BUY_LAPTOP = "BUY_LAPTOP";
export const BUY_MOBILE = "BUY_MOBILE";