import {combineReducers, createStore} from "redux";
import laptopReducer from "./Reducers/laptopReducer";
import mobileReducer from "./Reducers/mobileReducer";
const rootReducer = combineReducers({
    laptops: laptopReducer,
    mobiles: mobileReducer
})
const store = createStore(rootReducer);
export default store;
